﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GroundCheck : MonoBehaviour {

	Utility1 utility1;
	void Awake()
	{
		utility1 = GetComponentInParent<Utility1>();
	}

	void OnTriggerEnter2D(Collider2D other)
	{
		if (other.CompareTag("Ground"))
		{
			utility1.onGround = true;
		}
	}

	void OnTriggerStay2D(Collider2D other)
	{
		if (other.CompareTag("Ground"))
		{
			utility1.onGround = true;
		}
	}

	void OnTriggerExit2D(Collider2D other)
	{
		if (other.CompareTag("Ground"))
		{
			utility1.onGround = false;
		}
	}
}
