﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController : MonoBehaviour
{

    public GameObject bullet;
    public GameObject penetrateBullet;
    public GameObject rocketBullet;
    public GameObject laserbeam;
    public GameObject laserbeamprojectile;
    public GameObject gatlingBullet;

    // Use this for initialization
    void Start()
    {
       
    }

    // Update is called once per frame
    void Update()
    {

    }
}
