﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pin : MonoBehaviour {


    public bool HideIcon; //plan to use in later development for making waypoints not visible(not unlocked stages)
    public string SceneToLoad; //string name of the stage
    public int Stagenumber; //number of the stage in order of player progression starts from 0 to +1 for every new stage
   

    // Use this for initialization
    void Start () {
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
